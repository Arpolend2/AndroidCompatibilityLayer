# Droidmedia для FFmpeg n5.1.8 и mpv 0.37.0

Реализация аппаратного декодирования для Sailfish OS/Aurora OS с copy-back и
zero-copy через EGLImage. Предназначено для связки media_kit → libmpv → FFmpeg.

## Поддерживаемые декодеры

- `h264_droidmedia`
- `hevc_droidmedia`
- `vp8_droidmedia`
- `vp9_droidmedia`
- `mpeg2_droidmedia`
- `mpeg4_droidmedia`

В mpv доступны `hwdec=droidmedia` (EGL zero-copy),
`hwdec=droidmedia-gpu` (EGLImage → RGBA texture через GPU) и
`hwdec=droidmedia-copy` (YUV copy-back). Zero-copy и CPU copy-back включены в
автоматический probe; GPU copy выбирается явно. При ошибке mpv использует
обычные программные декодеры FFmpeg.

## Профили работы droidmedia в mpv

Это режимы передачи уже декодированного кадра, а не профили H.264/HEVC.
Во всех трёх режимах само декодирование выполняется аппаратным droidmedia
компонентом.

### `droidmedia` — EGL zero-copy

```text
DroidMediaBuffer → AV_PIX_FMT_DROIDMEDIA → EGLImage
                 → GL_TEXTURE_EXTERNAL_OES → отображение
```

- Кадр не копируется ни через CPU, ни в отдельную GPU-текстуру.
- mpv напрямую использует native buffer через EGLImage.
- FFmpeg удерживает BufferQueue slot, пока жив соответствующий `AVFrame`.
- Наиболее эффективный режим при достаточном количестве acquired buffers.
- Проверен на `192.168.1.110`. На старом droidmedia Android 10/R570E лимит
  двух acquired buffers может приводить к взаимной блокировке pipeline.

### `droidmedia-gpu` — копия средствами GPU

```text
DroidMediaBuffer → EGLImage → samplerExternalOES → FBO/RGBA texture
                 → glFinish → release AVFrame/BufferQueue slot
```

- GPU копирует кадр во внутреннюю RGBA-текстуру mpv.
- CPU не читает YUV и не загружает кадр в GPU.
- После завершения GPU-копии исходный native buffer сразу безопасно возвращается
  декодеру; последующее отображение использует только внутреннюю текстуру mpv.
- Устраняет зависимость от удержания нескольких droidmedia buffers.
- Требует OpenGL ES 3 и `GL_OES_EGL_image_external_essl3`.
- Выбирается явно; используется на R570E. Проверенная скорость — 29–31 FPS.

### `droidmedia-copy` — CPU copy-back

```text
DroidMediaBuffer → YUV/I420 AVFrame в RAM → GPU textures → отображение
```

- FFmpeg копирует YUV-плоскости в системную память и учитывает crop/stride.
- Поддерживаются I420/YV12/NV12; NV12 преобразуется в I420.
- Затем mpv загружает плоскости в GPU как обычные software frames.
- Требуется больше CPU и памяти, но это простой и надёжный fallback.

### Автоматические режимы

- `auto` / `auto-safe`: выбирают доступные whitelisted режимы, включая
  zero-copy и CPU copy-back. `droidmedia-gpu` в автоматический probe не входит.
- `auto-copy`: выбирает только copy-back режимы, включая `droidmedia-copy`.
- `no`: запрещает аппаратное декодирование и использует software decoder.
- Если droidmedia или нужный кодек недоступны, mpv сохраняет software fallback.

Для тестового media_kit plugin режим можно передать через окружение:

```sh
MEDIA_KIT_HWDEC=droidmedia       # настоящий zero-copy
MEDIA_KIT_HWDEC=droidmedia-gpu   # GPU copy
MEDIA_KIT_HWDEC=droidmedia-copy  # CPU copy-back
MEDIA_KIT_HWDEC=auto             # автоматический выбор
```

## Использование FFmpeg без mpv и выбор декодера

FFmpeg может декодировать видео без mpv. Например, проверить аппаратное
H.264-декодирование без сохранения результата:

```sh
ffmpeg -c:v h264_droidmedia -i input.mp4 -f null -
```

Или сохранить кадры в YUV через CPU copy-back:

```sh
ffmpeg -c:v h264_droidmedia -i input.mp4 \
  -pix_fmt yuv420p -f rawvideo output.yuv
```

Для EGL zero-copy и GPU copy требуется EGL/GL renderer; CLI без него выводит
кадры в RAM. Поэтому `droidmedia-gpu` реализован в mpv.

FFmpeg автоматически определяет кодек контейнера (H.264, HEVC, VP9 и другие),
но **не выбирает droidmedia вместо штатного декодера автоматически**. Без `-c:v`
CLI обычно использует software decoder. Приложение должно выбрать backend:

```c
if (av_droidmedia_is_available())
    decoder = avcodec_find_decoder_by_name("h264_droidmedia");
else
    decoder = avcodec_find_decoder(AV_CODEC_ID_H264);
```

При ошибке инициализации или декодирования необходимо повторно открыть поток с
обычным декодером:

```c
decoder = avcodec_find_decoder(AV_CODEC_ID_H264);
```

В mpv автоматический выбор и fallback уже выполняются через `hwdec=auto`,
`auto-safe` и `auto-copy`.

## Опциональная зависимость

Droidmedia не нужен ни для сборки приложения, ни для запуска на других
устройствах. Нет ссылки на `libdroidmedia.so` или `libhybris-common.so.1` в
`DT_NEEDED`.

Загрузчик выполняет:

```text
dlopen(libhybris-common.so.1)
  → android_dlopen(libdroidmedia.so)
  → android_dlsym(обязательные символы)
```

Обычный glibc `dlopen(libdroidmedia.so)` не используется: библиотека собрана
для Android/Bionic. При отсутствии libhybris, droidmedia, символа или кодека
инициализация возвращает ошибку без `abort()`. Handle остаётся открытым на всё
время жизни процесса, поскольку Binder/droidmedia являются process-wide API.

## Структура

### FFmpeg

- `libavcodec/droidmedia_loader.c` — безопасная runtime-загрузка;
- `libavcodec/droidmedia_internal.h` — ABI droidmedia без Android headers;
- `libavcodec/droidmediadec.c` — packet/frame queues, PTS, EOS, flush и YUV copy;
- `libavcodec/droidmedia.h` — публичное описание hardware buffer;
- `AV_PIX_FMT_DROIDMEDIA` — hardware frames, `data[0]` содержит
  `DroidMediaBuffer *`, `data[3]` — `AVDroidMediaBuffer *`;
- `AV_HWDEVICE_TYPE_DROIDMEDIA` и `libavutil/hwcontext_droidmedia.c` —
  device/frames metadata, необходимые для mpv hwupload.

H.264/HEVC используют штатные `h264_mp4toannexb`/`hevc_mp4toannexb` и
in-band parameter sets. Это также устраняет ошибку Android 13
`Cannot convertMetaDataToMessage()` при прямой передаче `kKeyAVCC/kKeyHVCC`.
Для copy-back запрашивается I420 и дополнительно поддержаны packed planar и
NV12. Hardware buffers удерживают refcount состояния декодера: старые кадры
остаются валидными во время seek/flush до своего освобождения.

### mpv

- `video/out/hwdec/hwdec_droidmedia.c` — `EGL_NATIVE_BUFFER_ANDROID` →
  `EGLImageKHR` → `GL_TEXTURE_EXTERNAL_OES`;
- `video/decode/vd_lavc.c` — регистрация direct/copy методов;
- `video/img_format.h`, `video/fmt-conversion.c` — mapping пиксельного формата.

Для сборки mpv требуется FFmpeg с установленным `libavcodec/droidmedia.h` и
символом `av_droidmedia_is_available`. Можно отключить через
`-Ddroidmedia=disabled`.

## Mimalloc

Сохранена схема из `~/mpv-build`: выделения mpv `ta_*` и libavutil FFmpeg
используют `mi_*`. При этом сборка унифицирована:

- используется mimalloc 2.2.4;
- одна shared `libmimalloc.so.2` обслуживает и mpv, и FFmpeg;
- mpv получает зависимость через `dependency('mimalloc')`, без отдельного
  CMake subproject;
- FFmpeg включает allocator через `--enable-mimalloc` и pkg-config;
- без этой опции используются штатные `malloc/realloc/free`;
- зависимость корректно попадает в `libavutil.pc`, поэтому не требуется ручное
  `-lmimalloc` при линковке только FFmpeg CLI;
- `libatomic.so.1` включается в bundle, поскольку она требуется mimalloc на
  ARM и отсутствует в базовой системе части устройств.

Проверка allocation/realloc/free:

```sh
tests/run-mimalloc-test.sh
```

## Сборка

Сначала собрать mimalloc в общий prefix, затем добавить его
`lib/pkgconfig` в `PKG_CONFIG_PATH` для FFmpeg и mpv. Пример опций находится
в `ffmpeg_options` и `mpv_options`. Минимальный набор:

```sh
ffmpeg/configure \
  --enable-droidmedia \
  --enable-decoder=h264_droidmedia \
  --enable-decoder=hevc_droidmedia \
  --enable-decoder=vp8_droidmedia \
  --enable-decoder=vp9_droidmedia \
  --enable-decoder=mpeg2_droidmedia \
  --enable-decoder=mpeg4_droidmedia
```

Затем установить FFmpeg и собрать mpv с `-Ddroidmedia=enabled`.
Существующий media_kit уже выставляет `hwdec=auto`, поэтому отдельного
изменения Dart/C++ texture-кода не требуется.

## Готовые артефакты

- `patches/ffmpeg-n5.1.8-droidmedia-mimalloc.patch` — droidmedia и mimalloc
  в FFmpeg;
- `patches/mpv-v0.37.0-aurora-droidmedia-mimalloc.patch` — droidmedia и
  mimalloc вместе с уже использовавшимися Aurora-правками mpv;
- `dist/aarch64/libmpv.so.2.2.0` и `dist/armv7hl/libmpv.so.2.2.0`;
- `dist/*/*.rpm` — временные FFmpeg CLI для проверки copy-back на устройстве.

## Проверки

Полный host-test запускается командой:

```sh
tests/run-host-tests.sh
```

Он проверяет отсутствие droidmedia, все шесть кодеков, copy-back, zero-copy,
PTS и flush при удерживаемых hardware buffers.

Ниже оставлены отдельные команды для ручной проверки. На хосте без droidmedia
`test_loader` должен вывести `no` и завершиться с 0. Fake Android loader и
fake decoder позволяют проверить остальную логику:

```sh
# После сборки и установки host-варианта FFmpeg в build/host-runtime/install:
gcc -shared -fPIC -Iffmpeg tests/fake_hybris.c -ldl \
  -Wl,-soname,libhybris-common.so.1 -o build/fake/libhybris-common.so.1
gcc -shared -fPIC -Iffmpeg tests/fake_droidmedia.c \
  -Wl,-soname,libdroidmedia.so -o build/fake/libdroidmedia.so

PREFIX="$PWD/build/host-runtime/install"
export PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig"
gcc -I"$PREFIX/include" tests/test_decoder.c -o build/tests/test-decoder \
  $(pkg-config --static --libs libavcodec) -ldl

LD_LIBRARY_PATH="$PWD/build/fake" build/tests/test-decoder copy-back
LD_LIBRARY_PATH="$PWD/build/fake" build/tests/test-decoder zero-copy
```

Тесты проверяют YUV/hardware format, размеры, PTS и отложенное уничтожение
кодека при удержанном hardware frame.

## Текущий статус проверки

- FFmpeg и libmpv успешно собраны в Aurora SDK 5.1.3.85 для aarch64 и armv7hl;
- host-тест без droidmedia проходит;
- mimalloc allocation/realloc/free-тест проходит;
- fake copy-back и zero-copy проходят для всех шести кодеков, включая flush;
- на `192.168.1.110` (MT6877) `example_player` воспроизвёл
  `/home/defaultuser/Videos/Default/Aurora_Tun_Loop.mp4` на 30 FPS;
- mpv подтвердил `Using hardware decoding (droidmedia)` и
  `hwdec-current: droidmedia`, EGL zero-copy работает;
- production RPM `dist/aarch64/ru.timoshn.example_player-0.1.0-29.aarch64.rpm`
  подписан regular developer key и установлен через APM;
- `armv7hl` на `192.168.1.50` (Android 10/R570E): H.264 стабильно работает
  через `droidmedia-gpu` на 29–31 FPS, без CPU copy-back.
